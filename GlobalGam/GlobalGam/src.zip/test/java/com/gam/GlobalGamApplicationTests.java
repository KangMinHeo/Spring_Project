package com.gam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GlobalGamApplicationTests {

	@Test
	void contextLoads() {
	}

}
