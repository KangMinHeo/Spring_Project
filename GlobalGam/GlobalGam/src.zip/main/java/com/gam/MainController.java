package com.gam;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gam.dto.EmployeeDTO;
import com.gam.service.EmployeeService;

@Controller
public class MainController {
	
	private EmployeeService eService;

	public MainController(EmployeeService eService) {
		this.eService = eService;
	}
	
	
	@Autowired
	HttpServletRequest request;
	
	
	@RequestMapping({"","/"})
	public String index() {	
		return "index";
	}
	
	@RequestMapping("/empInfo.do")
	public String empInfo() {
		
		List<EmployeeDTO> empList = eService.getAllEmpList();
		request.setAttribute("emp", empList);
		
		return "testEmpInfo";
	}
	
	@RequestMapping("/addrApi.do")
	public String addrApi() {
		
		return "addrApi";
	}
	
}
