package com.gam.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.gam.dto.EmployeeDTO;

@Mapper
public interface EmployeeMapper {

	List<EmployeeDTO> getAllEmpList();
	

}
