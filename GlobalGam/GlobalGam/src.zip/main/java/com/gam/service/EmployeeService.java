package com.gam.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.gam.dto.EmployeeDTO;
import com.gam.mapper.EmployeeMapper;

@Service
public class EmployeeService {
	
	private EmployeeMapper mapper;

	public EmployeeService(EmployeeMapper mapper) {
		this.mapper = mapper;
	}

	public List<EmployeeDTO> getAllEmpList() {
		return mapper.getAllEmpList();
	}
	
	
}
